﻿// See https://aka.ms/new-console-template for more information

//const int ValorMaximo = 100;

//string apellido;
//apellido = "Perez";

//int edad = 30;

//Console.WriteLine("Hola");
//Console.WriteLine(apellido);
//Console.WriteLine(edad);

//apellido = "Lopez";

//Console.WriteLine(apellido);

//Console.WriteLine(ValorMaximo);

//Console.WriteLine("Hola " + apellido);

float numero1 = 3.12345678901234567890f;
decimal numero2 = 3.12345678901234567890m;
double numero3 = 3.12345678901234567890;

Console.WriteLine("El numero 1 es: " + numero1);
Console.WriteLine("El numero 2 es: " + numero2);
Console.WriteLine("El numero 3 es: " + numero3);