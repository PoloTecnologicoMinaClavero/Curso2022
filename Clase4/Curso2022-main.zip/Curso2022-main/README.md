# Polo Tecnológico Mina Clavero
## Curso de Introduccion a NET 6.0 / Año 2022

Este repositorio es parte del curso de Introduccion a NET 6.0 dictado por el Polo Tecnologico Mina Clavero.
En este repositorio se encuentran los códigos usados de ejemplo en cada una de las clases.

Las clases se dictan por youtube, y pueden encontrarse aqui:

https://www.youtube.com/watch?v=z7swinNcri8&list=PLQAqNGvxctZQe3-Db9hZ4lNKaXupEq9el

